import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {summary,seedCases,transition,answerFor,escapeHTML,factsFor} from '../src/engine.mjs';
const data=JSON.parse(await readFile(new URL('../src/data.json',import.meta.url),'utf8'));
const at='2026-11-12T04:00:00.000Z';
test('source totals reconcile to the uploaded workbook, without using the account subset',()=>{
 const s=summary(data.daily);assert.equal(data.daily.length,30);assert.equal(s.cost,1287860.59);assert.equal(s.clicks,649179);assert.equal(s.applications,91108);assert.equal(s.cpc.toFixed(4),'1.9838');assert.equal(data.media.length,67);
 assert.equal(new Set(data.daily.map(r=>r.event_day)).size,30);
});
test('channel proxy is computed from the documented non-homogeneous sources',()=>{
 const r=data.daily.find(r=>r.event_day==='2026-10-13');assert.equal((r.apply_cnt/r.click*100).toFixed(2),'10.69');assert.equal(r.r4_fix,.6875);assert.match(factsFor('proxy',data).caveat,/非同源/);assert.match(factsFor('cpc',data).caveat,/未提供对应单元范围/);
});
test('decisions, execution evidence and followup are separate events; original is immutable',()=>{
 const initial=seedCases()[0];assert.throws(()=>transition(initial,'decision',{reason:'test',choice:'接受建议'},at),/先完成/);
 assert.throws(()=>transition(initial,'review',{reason:'test',verdict:'通过'},at),/补充至少/);
 let c=transition(initial,'evidence',{reason:'复现检查结果',reference:'TEST-01'},at);assert.equal(initial.evidence.length,0);assert.equal(c.version,2);assert.equal(c.status,'核验中');
 c=transition(c,'review',{reason:'核对来源、口径和前提',verdict:'通过'},at);assert.equal(c.status,'决策中');
 c=transition(c,'decision',{reason:'满足行动前提',choice:'接受建议'},at);assert.equal(c.status,'执行中');assert.equal(c.execution,undefined);
 assert.throws(()=>transition(c,'execution',{reason:'执行',date:at},at),/时间和凭证/);
 assert.throws(()=>transition(c,'execution',{reason:'执行',reference:'P-1',date:'2027-01-01'},at),/晚于/);
 c=transition(c,'execution',{reason:'记录外部实际动作',reference:'P-1',date:'2026-11-12T10:00:00+08:00'},at);assert.equal(c.status,'回访中');
 assert.throws(()=>transition(c,'followup',{reason:'观察',complete:false},at),/完整日报/);
 c=transition(c,'followup',{reason:'完成同范围核验，仅记录观察',complete:true,outcome:'已完成核验，关闭案件'},at);assert.equal(c.status,'已关闭');assert.equal(c.events.length,5);
 assert.throws(()=>transition(c,'evidence',{reason:'new'},at),/先重开/);
 c=transition(c,'reopen',{reason:'新证据'},at);assert.equal(c.status,'核验中');assert.equal(c.version,3);
});
test('a non-action decision closes with a reason and no invented execution',()=>{
 let c=seedCases()[0];c=transition(c,'evidence',{reason:'正常复现'},at);c=transition(c,'review',{reason:'证据完整',verdict:'通过'},at);c=transition(c,'decision',{reason:'确认正常',choice:'不采取动作'},at);assert.equal(c.status,'已关闭');assert.equal(c.execution,undefined);
});
test('assistant does not invent savings or early detection and discloses local fallback',()=>{
 assert.match(answerFor('省了多少钱？提前几天？',data).title,/无法确认/);assert.match(answerFor('你好',data).paragraphs.join(' '),/没有连接在线模型/);assert.match(answerFor('数据质量',data).paragraphs.join(' '),/813.*801/);assert.match(answerFor('CPC',data).paragraphs.join(' '),/1.5562/);
});
test('untrusted evidence text is escaped as text',()=>{
 assert.equal(escapeHTML('<img src=x onerror="alert(1)">'), '&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
});
