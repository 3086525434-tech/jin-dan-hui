import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {Window} from 'happy-dom';
const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
function setup(storage,{beforeLoad,url='http://localhost/'}={}){
 const w=new Window({url,settings:{enableJavaScriptEvaluation:true,disableCSSFileLoading:true,disableJavaScriptFileLoading:true}});
 const errors=[];w.addEventListener('error',e=>errors.push(e.message));if(storage)w.localStorage.setItem('manpan-demo-v1',storage);
 beforeLoad?.(w);w.document.write(html);w.document.close();return {w,d:w.document,errors};
}
function click(d,selector){const el=d.querySelector(selector);assert.ok(el,'Missing '+selector);el.click();return el;}
function input(w,d,selector,value){const el=d.querySelector(selector);assert.ok(el,'Missing '+selector);el.value=value;el.dispatchEvent(new w.Event('input',{bubbles:true}));return el;}
function submit(w,d,selector){d.querySelector(selector).dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));}
const delay=ms=>new Promise(r=>setTimeout(r,ms));
test('all six views mount, search filters, charts switch, and dialogs are labelled',async()=>{
 const {w,d,errors}=setup();try{
 assert.match(d.querySelector('h1').textContent,/链接数据与判断/);assert.match(d.body.textContent,/1,287,860.59/);
 for(const key of ['cases','agent','replay','data','rules','overview']){click(d,`.nav-item[href="#${key}"]`);assert.ok(d.querySelector('main h1'));assert.equal(d.querySelector('.nav-item[aria-current="page"]').getAttribute('href'),'#'+key);}
 d.querySelector('[data-action="metric"][data-value="conv"]').focus();click(d,'[data-action="metric"][data-value="conv"]');assert.equal(d.querySelector('.chart-tabs [role="tab"][aria-selected="true"]').textContent,'渠道 proxy');assert.equal(d.activeElement.id,'chart-tab-conv');
 click(d,'[data-action="range"][data-value="7"]');click(d,'[data-action="chart-table"]');assert.equal(d.querySelector('.chart-card tbody').children.length,7);
 click(d,'[data-action="go-cases"]');input(w,d,'#case-search','not-present');assert.match(d.querySelector('#case-table-region').textContent,/没有匹配/);input(w,d,'#case-search','CPC');assert.equal(d.querySelectorAll('#case-table-region tr[data-case]').length,1);
 click(d,'[data-action="search"]');await delay(10);assert.equal(d.querySelector('.modal').getAttribute('aria-modal'),'true');assert.ok(d.querySelector('#app').inert);input(w,d,'#global-search','快照');assert.equal(d.querySelectorAll('.search-result').length,1);click(d,'[data-action="search-case"]');assert.ok(d.querySelector('#drawer-title'));assert.equal(d.querySelector('.modal'),null);assert.ok(d.querySelector('#app').inert);click(d,'[data-action="drawer-close"]');assert.equal(d.querySelector('#app').inert,false);
 assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('reference-layout capability cards switch their detail group, persist in URL and support keyboard tabs',async()=>{
 const {w,d,errors}=setup();try{
 assert.equal(d.querySelectorAll('.capability-grid .capability').length,8);
 assert.ok(d.querySelector('.site-header .primary-nav'));
 assert.equal(d.querySelector('.sidebar'),null);
 const image=d.querySelector('.hero-visual img');assert.ok(image.getAttribute('width'));assert.ok(image.getAttribute('height'));assert.match(image.getAttribute('src'),/decision-chain/);
 click(d,'[data-action="capability"][data-value="M04"]');assert.equal(new URL(w.location.href).searchParams.get('capability'),'M04');assert.equal(d.querySelector('.feature-tabs [aria-selected=true]').dataset.value,'evidence');assert.match(d.querySelector('#feature-panel').textContent,/人工复现/);
 click(d,'[data-action="feature-tab"][data-value="action"]');assert.match(d.querySelector('#feature-panel').textContent,/执行时间与凭证登记/);assert.equal(d.querySelector('#feature-panel').getAttribute('aria-labelledby'),'feature-tab-action');
 d.querySelector('#feature-tab-action').dispatchEvent(new w.KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));assert.equal(d.querySelector('.feature-tabs [aria-selected=true]').dataset.value,'data');assert.equal(d.activeElement.id,'feature-tab-data');
 click(d,'[data-action="menu"]');assert.equal(d.querySelector('.mobile-menu').getAttribute('aria-expanded'),'true');assert.ok(d.querySelector('.primary-nav.open'));d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));assert.equal(d.querySelector('.mobile-menu').getAttribute('aria-expanded'),'false');
 assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('evidence to decision to execution to followup works in UI and persists',async()=>{
 const {w,d,errors}=setup();let saved;try{
 d.querySelector('[data-action="open-case"][data-id="DEMO-001"]').focus();click(d,'[data-action="open-case"][data-id="DEMO-001"]');d.querySelector('#drawer-tab-analysis').focus();d.querySelector('#drawer-tab-analysis').dispatchEvent(new w.KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));assert.equal(d.activeElement.id,'drawer-tab-timeline');assert.equal(d.querySelector('[role=tabpanel]#drawer-tab-panel').getAttribute('aria-labelledby'),'drawer-tab-timeline');click(d,'[data-action="case-form-evidence"]');input(w,d,'textarea[name="reason"]','<img src=x onerror=alert(1)> 已完成演示复现');input(w,d,'input[name="reference"]','P-01');submit(w,d,'#case-form');click(d,'[data-action="drawer-tab"][data-value="analysis"]');assert.equal(d.querySelector('.evidence-card img'),null);assert.match(d.querySelector('.evidence-card').textContent,/<img/);
 click(d,'[data-action="drawer-tab"][data-value="decision"]');click(d,'[data-action="case-form-review"]');d.querySelector('select[name="verdict"]').value='通过';input(w,d,'textarea[name="reason"]','证据、口径与行动前提已核对 / 演示');submit(w,d,'#case-form');assert.match(d.querySelector('.drawer-meta').textContent,/决策中/);
 click(d,'[data-action="case-form-decision"]');input(w,d,'textarea[name="reason"]','接受并安排执行 / 演示');submit(w,d,'#case-form');assert.match(d.querySelector('.drawer-meta').textContent,/执行中/);
 click(d,'[data-action="case-form-execution"]');input(w,d,'input[name="date"]','2026-11-01T10:00');input(w,d,'textarea[name="reason"]','登记外部动作 / 演示');input(w,d,'input[name="reference"]','EXEC-01');submit(w,d,'#case-form');assert.match(d.querySelector('.drawer-meta').textContent,/回访中/);
 click(d,'[data-action="case-form-followup"]');d.querySelector('input[name="complete"]').checked=true;input(w,d,'textarea[name="reason"]','完整日报已对照；仅作流程演示');submit(w,d,'#case-form');assert.match(d.querySelector('.drawer-meta').textContent,/已关闭/);saved=w.localStorage.getItem('manpan-demo-v1');assert.equal(JSON.parse(saved).cases[0].events.length,5);click(d,'[data-action="drawer-close"]');assert.equal(d.activeElement.dataset.id,'DEMO-001');assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
 const reload=setup(saved);try{assert.match(reload.d.querySelector('tr[data-case="DEMO-001"]').textContent,/已关闭/);assert.deepEqual(reload.errors,[]);}finally{await reload.w.happyDOM.close();}
});
test('chat produces source-backed local replies and run never duplicates cases',async()=>{
 const {w,d,errors}=setup();try{
 click(d,'[data-action="go-agent"]');click(d,'[data-action="ask"]');await delay(500);assert.equal(d.querySelectorAll('.message').length,2);assert.match(d.querySelector('.message:not(.user)').textContent,/本地数据解读/);assert.match(d.querySelector('.message:not(.user)').textContent,/1,287,860.59/);
 click(d,'.nav-item[href="#overview"]');click(d,'[data-action="run"]');click(d,'[data-action="run-start"]');await delay(1900);assert.match(d.querySelector('.modal-body').textContent,/演示完成/);const persisted=JSON.parse(w.localStorage.getItem('manpan-demo-v1'));assert.equal(persisted.cases.length,3);assert.equal(persisted.runs.length,1);click(d,'[data-action="run-finish"]');assert.equal(d.querySelector('h1').textContent,'案件工作台');assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('replay updates business data while retaining controller focus and truthful timing',async()=>{
 const {w,d,errors}=setup();try{click(d,'.nav-item[href="#replay"]');assert.equal(d.activeElement.id,'main');const before=d.querySelector('.replay-controller .date').textContent;const controller=d.querySelector('.replay-controller');const next=d.querySelector('[data-action="replay-next"]');next.focus();next.click();assert.equal(d.querySelector('.replay-controller'),controller);assert.equal(d.activeElement,next);assert.notEqual(d.querySelector('.replay-controller .date').textContent,before);const play=d.querySelector('[data-action=replay-play]');play.focus();play.click();await delay(1200);assert.equal(d.querySelector('.replay-controller'),controller);assert.equal(d.activeElement,play);play.click();assert.match(d.querySelector('.content').textContent,/不计算真实提前/);assert.deepEqual(errors,[]);}finally{await w.happyDOM.close();}
});
test('leaving mobile width closes the nav and releases its scroll lock',async()=>{
 const {w,d,errors}=setup();try{w.happyDOM.setWindowSize({width:390,height:844});assert.match(d.querySelector('.trend-svg').getAttribute('viewBox'),/0 0 360 /);click(d,'[data-action=menu]');assert.equal(d.body.style.overflow,'hidden');w.happyDOM.setWindowSize({width:1440,height:1000});assert.match(d.querySelector('.trend-svg').getAttribute('viewBox'),/0 0 720 /);assert.equal(d.querySelector('.mobile-menu').getAttribute('aria-expanded'),'false');assert.equal(d.body.style.overflow,'');assert.deepEqual(errors,[]);}finally{await w.happyDOM.close();}
});
test('switching work groups keeps controls mounted and presents readable, source-backed summaries',async()=>{
 const {w,d,errors}=setup();try{
 const grid=d.querySelector('.capability-grid'),tabs=d.querySelector('.feature-tabs'),panel=d.querySelector('#feature-panel');
 assert.match(panel.querySelector('.spot-readout').textContent,/64.92/);
 assert.equal(panel.querySelector('.mini-window'),null);
 for(const group of ['evidence','action','data','action','evidence']){
  click(d,`[data-action="feature-tab"][data-value="${group}"]`);
  assert.equal(d.querySelector('.capability-grid'),grid);
  assert.equal(d.querySelector('.feature-tabs'),tabs);
  assert.equal(d.querySelector('#feature-panel'),panel);
  assert.equal(d.activeElement.id,'feature-tab-'+group);
  assert.equal(panel.querySelector('.spot-stage').dataset.group,group);
  const ids=[...panel.querySelectorAll('[id]')].map(el=>el.id);assert.equal(new Set(ids).size,ids.length);
 }
 assert.match(panel.querySelector('.spot-readout').textContent,/0.6875×/);
 assert.match(panel.querySelector('.spot-note').textContent,/不直接证明故障/);
 assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('motion remains interruptible, responds to live reduced-motion preferences, and never delays navigation',async()=>{
 const animations=[];let preference;
 const {w,d,errors}=setup(undefined,{beforeLoad(w){
  const match=w.matchMedia.bind(w);preference=new w.EventTarget();preference.matches=false;
  w.matchMedia=query=>query==='(prefers-reduced-motion: reduce)'?preference:match(query);
  w.Element.prototype.animate=function(frames,options){
   let resolve;const animation={element:this,frames,options,cancelled:false,finished:new Promise(r=>resolve=r),cancel(){this.cancelled=true;resolve();}};
   animations.push(animation);return animation;
  };
 }});try{
 click(d,'[data-action="feature-tab"][data-value="evidence"]');
 assert.ok(animations.at(-1).frames.some(frame=>frame.transform));
 const first=animations.at(-1);
 click(d,'[data-action="feature-tab"][data-value="action"]');assert.ok(first.cancelled);
 const second=animations.at(-1);preference.matches=true;preference.dispatchEvent(new w.Event('change'));assert.ok(second.cancelled);
 click(d,'[data-action="feature-tab"][data-value="data"]');
 assert.ok(animations.at(-1).frames.every(frame=>!frame.transform));assert.ok(animations.at(-1).options.duration<=150);
 click(d,'.nav-item[href="#cases"]');assert.equal(d.querySelector('h1').textContent,'案件工作台');assert.equal(d.activeElement.id,'main');
 assert.ok(animations.every(a=>a.options.duration<=250));assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('responsive CSS applies two-column capabilities and readable summaries at phone and tablet widths',async()=>{
 for(const width of [390,768,1440]){
  const {w,d}=setup(undefined,{beforeLoad:w=>w.happyDOM.setWindowSize({width,height:900})});try{
   const style=selector=>w.getComputedStyle(d.querySelector(selector));
   assert.match(style('.capability-grid').gridTemplateColumns,width<=860?/repeat\(2,/:/repeat\(4,/);
   assert.ok(parseFloat(style('.capability-description').fontSize)>=12);
   assert.ok(parseFloat(style('.spot-note').fontSize)>=11);
   if(width<=860)assert.equal(style('.feature-panel').gridTemplateColumns,'1fr');
   if(width<=600){click(d,'.nav-item[href="#agent"]');assert.ok(parseFloat(style('.composer-send').width)>=44);}
  }finally{await w.happyDOM.close();}
 }
});
test('restored chain and share dialog copy a clean URL without local records or unknown query parameters',async()=>{
 let copied='';const {w,d,errors}=setup(undefined,{url:'http://localhost/?token=not-for-sharing#data',beforeLoad(w){Object.defineProperty(w.navigator,'clipboard',{configurable:true,value:{writeText:async value=>{copied=value;}}});}});try{
 click(d,'.nav-item[href="#overview"]');assert.match(d.querySelector('.hero-chain').src,/decision-chain.webp/);assert.equal(d.querySelector('[data-action="hero-link"]'),null);
 click(d,'.nav-item[href="#data"]');const opener=d.querySelector('.share-trigger');opener.focus();opener.click();
 assert.equal(d.querySelector('#share-url').readOnly,true);assert.equal(d.querySelector('#share-url').value,'http://localhost/#data');
 click(d,'[data-action="copy-share"]');await delay(5);assert.equal(copied,'http://localhost/#data');assert.match(d.querySelector('#toast-root').textContent,/已复制/);
 assert.match(d.querySelector('.modal-body').textContent,/不会同步/);click(d,'[data-action="modal-close"]');assert.equal(d.activeElement,opener);assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
test('integration checks remain truthful and make no requests while interfaces are deferred',async()=>{
 let calls=0;const {w,d,errors}=setup(undefined,{beforeLoad(w){w.fetch=async()=>{calls++;throw Error('unexpected network');};}});try{
 click(d,'.nav-item[href="#data"]');assert.equal(d.querySelectorAll('.integration-card').length,2);assert.equal(d.querySelector('[data-action="preview-live-data"]').disabled,true);
 click(d,'[data-action="check-connections"]');await delay(10);assert.equal(calls,0);assert.equal(d.querySelectorAll('.integration-state').length,2);assert.ok([...d.querySelectorAll('.integration-state')].every(el=>/尚未配置/.test(el.textContent)));
 click(d,'[data-action="integration-guide"]');assert.match(d.querySelector('.modal-body').textContent,/稍后对接/);assert.equal(d.querySelector('a[href="docs/integration-openapi.json"]').hasAttribute('download'),true);assert.deepEqual(errors,[]);
 }finally{await w.happyDOM.close();}
});
