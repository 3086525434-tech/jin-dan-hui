import test from 'node:test';
import assert from 'node:assert/strict';
import {createApiClient,validateDataset,validateAnalysis,validBusinessDay} from '../src/api-client.mjs';
const payload=()=>({schemaVersion:'1.0',batch:{id:'BATCH-EXAMPLE',source:'业务系统示例',generatedAt:'2026-11-12T09:00:00+08:00',channel:'CH-EXAMPLE',start:'2026-11-01',end:'2026-11-03',currency:'CNY',grain:'channel_day',applicationsScope:'all_channel'},daily:[{event_day:'2026-11-03',cost_yuan:20.02,click:0,apply_cnt:2,conv:99},{event_day:'2026-11-01',cost_yuan:10.01,click:100,apply_cnt:10,conv:99}]});
const json=data=>new Response(JSON.stringify(data),{headers:{'content-type':'application/json'}});
test('API batches derive ratios, preserve missing days, sort rows, and do not mutate the source',()=>{
 const input=payload(),result=validateDataset(input);
 assert.equal(result.daily[0].event_day,'2026-11-01');assert.equal(result.daily[0].conv,.1);assert.equal(result.daily[1].conv,null);
 assert.equal(result.totals.cost,30.03);assert.equal(result.totals.clicks,100);assert.equal(result.totals.applications,12);
 assert.equal(result.quality.missingDays,1);assert.equal(result.daily.length,2);assert.equal(input.daily[0].conv,99);
});
test('invalid dates, duplicate grain, missing source and incompatible scopes block data preview',()=>{
 assert.equal(validBusinessDay('2026-02-30'),false);assert.equal(validBusinessDay('2024-02-29'),true);
 for(const mutate of [p=>p.daily.push({...p.daily[0]}),p=>p.daily[0].event_day='2026-02-30',p=>p.daily[0].click=1.5,p=>p.daily[0].cost_yuan=-2,p=>p.daily[0].cost_yuan=Infinity,p=>p.daily[0].apply_cnt='2',p=>p.batch.source='',p=>p.batch.grain='unit_day',p=>p.batch.start='2026-10-01',p=>p.batch.generatedAt='2026-11-12']){
  const input=payload();mutate(input);assert.throws(()=>validateDataset(input));
 }
});
test('unconfigured services never make network calls or pretend to be connected',async()=>{
 let calls=0;const client=createApiClient({},async()=>{calls++;throw Error('must not fetch');});
 const status=await client.status();assert.equal(status.data.state,'not_configured');assert.equal(status.agent.state,'not_configured');
 await assert.rejects(client.dataset(),e=>e.code==='not_configured');await assert.rejects(client.analyze({question:'x',batchId:'x'}),e=>e.code==='not_configured');assert.equal(calls,0);
});
test('health checks detect HTML fallbacks and authorization errors independently',async()=>{
 const client=createApiClient({dataApiEnabled:true,agentApiEnabled:true},async url=>url.includes('/data/')?new Response('<html>app</html>',{headers:{'content-type':'text/html'}}):new Response('',{status:403}));
 const status=await client.status();assert.equal(status.data.state,'unavailable');assert.equal(status.data.code,'invalid_response');assert.equal(status.agent.code,'http_403');
});
test('configured adapter uses the documented same-origin gateway and validates its payload',async()=>{
 const calls=[];const client=createApiClient({dataApiEnabled:true,agentApiEnabled:true},async(url,options)=>{
  calls.push({url,options});if(url.endsWith('/data/health'))return json({ok:true,service:'data'});if(url.endsWith('/agent/health'))return json({ok:true,service:'agent'});if(url.endsWith('/datasets/current'))return json(payload());return json({answer:'先补齐来源凭证。',requestId:'REQ-EXAMPLE',sources:[{label:'来源',reference:'E-EXAMPLE'}]});
 });
 const health=await client.status();assert.equal(health.data.state,'reachable');assert.equal(health.agent.state,'reachable');
 const dataset=await client.dataset();assert.equal(dataset.batch.id,'BATCH-EXAMPLE');
 const answer=await client.analyze({question:'哪些证据还缺少？',batchId:'BATCH-EXAMPLE',caseId:'CASE-EXAMPLE'});assert.equal(answer.sources.length,1);
 const post=calls.at(-1);assert.equal(post.url,'/api/analysis');assert.equal(post.options.method,'POST');assert.equal(JSON.parse(post.options.body).batchId,'BATCH-EXAMPLE');assert.ok(calls.every(c=>c.options.credentials==='same-origin'&&c.options.redirect==='error'&&c.options.cache==='no-store'));
 assert.throws(()=>createApiClient({apiBasePath:'https://elsewhere.example'}));assert.throws(()=>createApiClient({apiBasePath:'//elsewhere.example'}));
});
test('timeouts settle as unavailable and analysis responses require evidence references',async()=>{
 const client=createApiClient({dataApiEnabled:true,timeoutMs:50},async(_url,options)=>new Promise((_resolve,reject)=>options.signal.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')))));
 const status=await client.status();assert.equal(status.data.code,'timeout');
 assert.throws(()=>validateAnalysis({answer:'无来源的结论',requestId:'REQ',sources:[]}));
});
