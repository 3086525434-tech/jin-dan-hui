# Manpan Spotkit illustrations

These are abstract vector illustrations, not screenshots or proof of an actual system action. Source layout geometry is preserved from Spotkit.

| Asset | Feature interpretation / metaphor | Layout / primitives |
|---|---|---|
| data-connect.svg | Sources join one operating context | L9 gateway: four source tiles, dashed connections, one raised database hub, panel |
| evidence-review.svg | Evidence moves from unreviewed to reviewed | L12 approval: two state cards, one arrow, a file medallion, panel |
| action-followup.svg | Decision, execution and followup remain chronological | L11 timeline: rail with three nodes, paired bars, clock chip, panel |

All use a 160-square viewBox, exact upstream panel/float/card coordinates, a shared 0.5 structural stroke and Phosphor regular filled paths. Token fallbacks are rethemed to Manpan: cool neutral surfaces and one violet/orange/gold accent by group. SVG ids are suffixed with the asset name to prevent mask and filter collisions. Inline markup is preferred for token theming; external img uses documented fallback colors.

Each file can scale to 200–280 CSS pixels without altering the viewBox. No animation is baked into these assets; the application owns state transitions and reduced-motion behavior.

License: adapted Spotkit source is MIT (Devesh Shirsath, 2026). The Phosphor paths bundled by Spotkit are MIT (Phosphor Icons). Retain attribution when redistributing. Exact source identities, license text and hashes appear in SOURCE.json.
