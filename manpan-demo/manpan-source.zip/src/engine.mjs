export const STAGES = ['核验中', '补证中', '审查中', '决策中', '执行中', '回访中', '已关闭'];
export const fmt = (n, digits = 0) => Number(n).toLocaleString('zh-CN', {minimumFractionDigits: digits, maximumFractionDigits: digits});
export const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const total = (rows, key) => rows.reduce((sum, row) => sum + Number(row[key] || 0), 0);
export function summary(rows) {
  const cost = total(rows, 'cost_yuan'), clicks = total(rows, 'click'), applications = total(rows, 'apply_cnt');
  return {cost: Math.round(cost * 100) / 100, clicks, applications, cpc: clicks ? cost / clicks : null, proxy: clicks ? applications / clicks : null};
}
export function seedCases() {
  return [
    {id:'DEMO-001', title:'渠道 proxy 下降，需核验原因', scope:'CH-07 · 渠道级', rule:'R4', day:'2026-10-13', status:'补证中', owner:'岳悦', version:1, kind:'proxy', evidence:[], events:[]},
    {id:'DEMO-002', title:'CPC 连续变化，需比对流量结构', scope:'CH-07-FEED · 汇总观察', rule:'R3 观察', day:'2026-11-02', status:'核验中', owner:'岳悦', version:1, kind:'cpc', evidence:[], events:[]},
    {id:'DEMO-003', title:'重复快照引用，待完成属性比对', scope:'对象快照 · 数据质检', rule:'批次质检', day:'2026-10-18', status:'补证中', owner:'岳悦', version:1, kind:'snapshot', evidence:[], events:[]}
  ];
}
export function factsFor(kind, data) {
  if (kind === 'proxy') {
    const r = data.daily.find(r => r.event_day === '2026-10-13');
    return {title:'10 月 13 日的渠道近似比值较固定基线下降 31.25%。', rows:[['业务日',r.event_day],['APP 全渠道申请',fmt(r.apply_cnt)+' 笔'],['feed CPC 点击',fmt(r.click)+' 次'],['渠道 proxy',fmt(r.apply_cnt/r.click*100,2)+'%'],['固定基线 proxy','15.542%'],['比值倍数（原表）',r.r4_fix+'×']], source:'渠道规则 · 2026-10-13；规则参数', caveat:'申请与点击并非同源。R4 只作为渠道 proxy，不等于单元转化率，也不能据此确认落地页故障。'};
  }
  if (kind === 'cpc') return {title:'滚动基线下，11 月 2 日与 3 日 CPC 倍数分别为 1.5562×、1.4762×。',rows:[['观察范围','CH-07-FEED 渠道汇总'],['2026-11-02 · 滚动倍数','1.5562×'],['2026-11-03 · 滚动倍数','1.4762×'],['固定 7 日结果','0 个命中日'],['滚动 7 日结果','2 个命中日']],source:'汇总校验 · R3；渠道规则 · r3_mult',caveat:'附件提供渠道汇总结果，未提供对应单元范围；此处作为观察线索，不计入单元案件数。'};
  return {title:'来源标识 6 处重复快照引用，正式复用仍需完整属性比对凭证。',rows:[['重复引用日','09.13、09.26、09.27、10.02、10.03、10.18'],['10.18 引用分区','2026-10-17'],['源表标识','四项指纹相同'],['完整属性比对凭证','附件未提供'],['PRD V1.7 要求','完整属性逐行比对通过后才可复用']],source:'对象快照；汇总校验；PRD V1.7 附录 L.2',caveat:'工作簿中的 dup_full 结论不代替完整比对凭证。属性复用不复制费用，也不删除不同业务日的真实消耗。'};
}
export function transition(item, action, payload, at) {
  const c = JSON.parse(JSON.stringify(item)), reason = String(payload.reason || '').trim();
  if (!reason) throw new Error('请填写理由或记录内容。');
  let label;
  if (action === 'evidence') {
    if (c.status === '已关闭') throw new Error('请先重开案件再补充证据。');
    c.evidence.push({id:'LOCAL-'+(c.evidence.length+1),content:reason,reference:String(payload.reference||''),at});
    c.version += 1; c.status = '核验中'; label = '补充演示证据';
  } else if (action === 'review') {
    if (!['核验中','补证中','审查中'].includes(c.status)) throw new Error('当前阶段不能登记审查。');
    if (payload.verdict === '通过') {if(!c.evidence.length) throw new Error('请先补充至少一条证据，再登记演示审查。'); c.status='决策中';}
    else c.status='补证中';
    label='人工登记演示审查：'+payload.verdict;
  } else if (action === 'decision') {
    if(c.status!=='决策中') throw new Error('请先完成证据补录和审查登记。');
    c.status=payload.choice==='不采取动作'?'已关闭':'执行中';
    c.decision={choice:payload.choice,reason,at};label='业务决定：'+payload.choice;
  } else if (action === 'execution') {
    if(c.status!=='执行中') throw new Error('请先记录接受或修改建议的业务决定。');
    if(!String(payload.reference||'').trim() || !payload.date) throw new Error('请填写执行时间和凭证引用。');
    if(!Number.isFinite(Date.parse(payload.date))) throw new Error('执行时间无效。');
    if(Date.parse(payload.date)>Date.parse(at)) throw new Error('执行时间不能晚于当前时间。');
    c.execution={reason,reference:payload.reference,date:payload.date,at};c.status='回访中';label='登记演示执行凭证';
  } else if (action === 'followup') {
    if(c.status!=='回访中') throw new Error('请先登记执行凭证。');
    if(!payload.complete) throw new Error('请确认执行后的完整日报已经到齐。');
    c.status=payload.outcome==='问题持续，重新核验'?'核验中':'已关闭';c.followup={reason,outcome:payload.outcome,at};label='回访：'+payload.outcome;
  } else if (action === 'reopen') {
    if(c.status!=='已关闭') throw new Error('只有已关闭案件可以重开。');
    c.status='核验中';c.version+=1;label='重开演示案件';
  } else throw new Error('未知操作。');
  c.events.push({action,label,reason,at,reference:payload.reference||''});
  return c;
}
export function answerFor(question, data) {
  const q=question.toLowerCase(), s=summary(data.daily);
  if(/节省|收益|早发现|提前/.test(q)) return {title:'目前无法确认实际收益或提前发现天数。',paragraphs:['附件没有足够的人工发现时间、执行凭证及可比性审查材料。按照 PRD V1.7，提前天数应保持待补证，收益也不能由消耗下降直接推算。','建议在案件中补入真实发现、业务决定、执行和回访记录，再进行验证。'],source:'PRD V1.7 · M06 / M07',kind:'proxy'};
  if(/proxy|r4|申请|转化|落地页/.test(q)) return {title:'先核验 10 月 13 日的渠道 proxy 变化。',paragraphs:['当日 APP 全渠道申请 2,893 笔、feed CPC 点击 27,074 次，proxy 为 10.69%；原表固定基线倍数为 0.6875×，下降 31.25%。','这是一条渠道级线索。流量结构、跨日申请、其他计费来源或页面跳转均需进一步核验；附件不足以确认任何一种原因。'],source:'渠道规则 · 2026-10-13；规则参数',kind:'proxy'};
  if(/快照|重复|分区|质量|完整|数据/.test(q)) return {title:'优先补齐重复快照的完整属性比对凭证。',paragraphs:['文件覆盖 67 个业务日，媒体 cost / click 空值检查通过。来源标识 6 处重复分区引用。','PRD V1.7 要求四项指纹和完整属性逐行比对均通过后才可正式复用；当前附件未提供完整比对凭证。零消耗账户口径也存在差异：工作簿记 813，PRD 修订记 801，需重新核对，不能据此计算账户覆盖率。'],source:'汇总校验；账户盘点；PRD V1.7 附录 L',kind:'snapshot'};
  if(/cpc|r3|点击成本|点击单价/.test(q)) return {title:'CPC 的变化需要同时看固定和滚动基线。',paragraphs:[`30 天渠道加权 CPC 为 ¥${fmt(s.cpc,4)}，由渠道消耗除以点击计算。`,'来源中的 R3 固定 7 日结果为 0 个命中日；滚动 7 日结果为 2 个命中日，11 月 2 日 1.5562×、11 月 3 日 1.4762×。两套结果应分开保存，不能合并成单元案件。'],source:'汇总校验 · R3；渠道规则',kind:'cpc'};
  if(/花费|消耗|概览|总结|情况|关注|优先|异常|核验/.test(q)) return {title:'从三条线索开始，逐项收集证据。',paragraphs:[`2026.10.06–11.04，渠道消耗 ¥${fmt(s.cost,2)}，点击 ${fmt(s.clicks)} 次，APP 全渠道申请 ${fmt(s.applications)} 笔。`,'建议优先查看 10 月 13 日渠道 proxy 下降，其次比对 11 月 2–3 日 CPC 的滚动基线变化，并补齐 6 处重复快照的属性比对凭证。当前没有已确认故障或已验证收益。'],source:'渠道规则；汇总校验；PRD V1.7',kind:'proxy'};
  return {title:'可以从已导入的数据开始核验。',paragraphs:['这是本地演示助理，使用附件数据和预设核验逻辑，没有连接在线模型。当前支持渠道消耗、CPC、渠道 proxy、数据质量和收益口径。','试试问「有哪些值得优先核验的线索？」或「为什么不能把消耗下降算成收益？」。其他问题请补充对应数据后再核验。'],source:'演示能力说明',kind:null};
}
