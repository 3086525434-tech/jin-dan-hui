export class ApiError extends Error {
  constructor(code,message){super(message);this.name='ApiError';this.code=code;}
}
export function validBusinessDay(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
  const time=Date.parse(value+'T00:00:00Z');
  return Number.isFinite(time)&&new Date(time).toISOString().slice(0,10)===value;
}
function requiredText(value,label,max=500){
  if(typeof value!=='string'||!value.trim()||value.length>max)throw new ApiError('invalid_schema',label+'缺失或格式无效。');
  return value.trim();
}
export function validateDataset(payload){
  const fail=message=>{throw new ApiError('invalid_dataset',message);};
  if(!payload||payload.schemaVersion!=='1.0'||!payload.batch)fail('数据批次版本或来源信息缺失。');
  const raw=payload.batch;
  const batch={id:requiredText(raw.id,'批次编号',128),source:requiredText(raw.source,'数据来源',500),channel:requiredText(raw.channel,'渠道',100),generatedAt:requiredText(raw.generatedAt,'生成时间',80),start:raw.start,end:raw.end,currency:raw.currency,grain:raw.grain,applicationsScope:raw.applicationsScope};
  if(!Number.isFinite(Date.parse(batch.generatedAt))||!/T.*(?:Z|[+-]\d{2}:\d{2})$/i.test(batch.generatedAt))fail('批次生成时间应为包含时区的日期时间。');
  if(!validBusinessDay(batch.start)||!validBusinessDay(batch.end)||batch.start>batch.end)fail('观察窗口无效。');
  if(batch.currency!=='CNY'||batch.grain!=='channel_day'||batch.applicationsScope!=='all_channel')fail('当前预览仅接受人民币、渠道日粒度及 APP 全渠道申请口径。');
  if(!Array.isArray(payload.daily)||payload.daily.length<1||payload.daily.length>3660)fail('日报应包含 1 至 3660 行。');
  const days=new Set();
  const daily=payload.daily.map(row=>{
    if(!row||!validBusinessDay(row.event_day)||row.event_day<batch.start||row.event_day>batch.end)fail('日报包含无效日期或超出观察窗口。');
    if(days.has(row.event_day))fail('同一渠道存在重复业务日，请先在来源端对账。');
    days.add(row.event_day);
    for(const key of ['cost_yuan','click','apply_cnt'])if(typeof row[key]!=='number'||!Number.isFinite(row[key])||row[key]<0)fail('消耗、点击及申请必须为非负有限数值。');
    if(!Number.isSafeInteger(row.click)||!Number.isSafeInteger(row.apply_cnt))fail('点击与申请必须为有效整数。');
    return {event_day:row.event_day,cost_yuan:row.cost_yuan,click:row.click,apply_cnt:row.apply_cnt,conv:row.click?row.apply_cnt/row.click:null};
  }).sort((a,b)=>a.event_day.localeCompare(b.event_day));
  if(daily[0].event_day!==batch.start||daily.at(-1).event_day!==batch.end)fail('批次起止日与日报范围不一致。');
  const totals=daily.reduce((s,row)=>({cost:s.cost+row.cost_yuan,clicks:s.clicks+row.click,applications:s.applications+row.apply_cnt}),{cost:0,clicks:0,applications:0});
  if(!Number.isFinite(totals.cost)||!Number.isSafeInteger(totals.clicks)||!Number.isSafeInteger(totals.applications))fail('批次汇总超出可可靠计算的范围。');
  const cents=Math.round(totals.cost*100);
  if(!Number.isSafeInteger(cents))fail('批次金额超出可可靠计算的范围。');
  totals.cost=cents/100;
  totals.cpc=totals.clicks?totals.cost/totals.clicks:null;
  const expectedDays=Math.round((Date.parse(batch.end)-Date.parse(batch.start))/86400000)+1;
  return {batch,daily,totals,quality:{missingDays:expectedDays-days.size}};
}
export function validateAnalysis(payload){
  if(!payload||!Array.isArray(payload.sources)||payload.sources.length<1||payload.sources.length>20)throw new ApiError('invalid_schema','分析回答需要提供 1 至 20 条来源引用。');
  return {answer:requiredText(payload.answer,'分析回答',20000),requestId:requiredText(payload.requestId,'请求编号',128),sources:payload.sources.map(source=>({label:requiredText(source?.label,'来源名称',200),reference:requiredText(source?.reference,'来源引用',1000)}))};
}
export function createApiClient(config={},fetchImpl=globalThis.fetch){
  const base=config.apiBasePath||'/api';
  if(typeof base!=='string'||!/^\/(?!\/)[A-Za-z0-9/_-]*$/.test(base))throw new ApiError('invalid_config','接入地址必须为本站服务端路径。');
  const prefix=base.replace(/\/+$/,'')||'/api';
  const enabled={data:config.dataApiEnabled===true,agent:config.agentApiEnabled===true};
  const timeoutMs=Math.min(30000,Math.max(50,Number(config.timeoutMs)||8000));
  async function request(path,options={}){
    if(typeof fetchImpl!=='function')throw new ApiError('unsupported','当前浏览器无法发起请求。');
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const response=await fetchImpl(prefix+path,{...options,headers:{Accept:'application/json',...(options.body?{'Content-Type':'application/json'}:{})},credentials:'same-origin',redirect:'error',cache:'no-store',signal:controller.signal});
      if(!response.ok)throw new ApiError('http_'+response.status,[401,403].includes(response.status)?'接口需要授权，请由管理员配置。':'接口暂不可用，请稍后重试。');
      if(!/application\/json/i.test(response.headers.get('content-type')||''))throw new ApiError('invalid_response','接口未返回 JSON 数据，不能视为已接通。');
      const text=await response.text();
      if(text.length>2*1024*1024)throw new ApiError('response_size','数据批次过大，请按观察窗口分批读取。');
      try{return JSON.parse(text);}catch{throw new ApiError('invalid_response','接口返回的数据格式无效。');}
    }catch(error){
      if(error instanceof ApiError)throw error;
      if(controller.signal.aborted||error?.name==='AbortError')throw new ApiError('timeout','接口响应超时，请稍后重试。');
      throw new ApiError('network','无法连接接口，请检查服务端状态。');
    }finally{clearTimeout(timer);}
  }
  function requireEnabled(service){if(!enabled[service])throw new ApiError('not_configured',service==='data'?'业务数据接口尚未配置。':'分析 Agent 接口尚未配置。');}
  async function health(service){
    if(!enabled[service])return {state:'not_configured',message:'尚未配置接口'};
    try{const result=await request('/integrations/'+service+'/health');if(result?.ok!==true||result?.service!==service)throw new ApiError('invalid_response','接口健康响应与服务类型不匹配。');return {state:'reachable',message:'接口可达'};}
    catch(error){return {state:'unavailable',message:error.message,code:error.code};}
  }
  return {
    enabled:{...enabled},
    status:async()=>{const [data,agent]=await Promise.all([health('data'),health('agent')]);return {data,agent};},
    dataset:async()=>{requireEnabled('data');return validateDataset(await request('/datasets/current'));},
    analyze:async({question,batchId,caseId}={})=>{requireEnabled('agent');const body={question:requiredText(question,'问题',2000),batchId:requiredText(batchId,'批次编号',128)};if(caseId)body.caseId=requiredText(caseId,'案件编号',128);return validateAnalysis(await request('/analysis',{method:'POST',body:JSON.stringify(body)}));}
  };
}
