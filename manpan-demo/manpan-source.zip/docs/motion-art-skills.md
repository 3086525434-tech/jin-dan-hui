# New design and motion skills

Downloaded from GitHub, reviewed, and installed in the current environment under `~/.agents/skills/`, with compatibility links under `~/.codex/skills/`. No upstream installer, automatic hooks or scripts were executed. These are filesystem Agent Skills; this does not claim account-wide registration.

- **motion-design** — https://github.com/LottieFiles/motion-design-skill
  Commit: `f9a8a041b85185ee4881b3471d3415e939aac772`
- **design-motion-principles** — https://github.com/kylezantos/design-motion-principles
  Commit: `4a9ca879f24a361f4dca4174fe2da0f67b5ddee3`
- **animated-svg-icons** — https://github.com/ConvenientSolutions/animated-svg-icons
  Commit: `ffa04a57cbdd3b10998a7d6e95a83d7e0e2c21b5`
- **design-taste-frontend-v1** — https://github.com/Leonxlnx/taste-skill-classics
  Commit: `5e08c9383dc4ad7fc0df70e1ac8cfa09ec356305`

The homepage refinement uses the Premium motion personality (controlled curves, no overshoot), meaningful data-to-judgment choreography, interruptible feedback, and independent SVG overlay elements. Existing vanilla HTML/CSS/JS, established brand palette and business behavior are retained. Broad page templates, perpetual loops, framework migrations and unrelated rules are outside this request.

To use the bundle in another local Agent Skills environment, copy each skill directory into that agent's skills folder and reload its skill discovery. Each folder includes upstream instructions, references, MIT license and a SOURCE.json file with version and hashes.
