import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
const read=name=>readFile(new URL(name,import.meta.url),'utf8');
const [template,css,engine,app,data]=await Promise.all(['src/template.html','src/style.css','src/engine.mjs','src/app.js','src/data.json'].map(read));
const illustrationFiles={data:'data-connect.svg',evidence:'evidence-review.svg',action:'action-followup.svg'};
const illustrations=Object.fromEntries(await Promise.all(Object.entries(illustrationFiles).map(async([key,file])=>[key,await read('src/assets/spotkit/'+file)])));
const featureIcons=JSON.parse(await read('src/assets/feature-icons.json'));
const runtime=JSON.parse(await read('src/runtime-config.json'));
const api=await read('src/api-client.mjs');
const script='(()=>{\n"use strict";\nconst FEATURE_ART='+JSON.stringify(illustrations)+';\nconst FEATURE_ICONS='+JSON.stringify(featureIcons)+';\nconst RUNTIME_CONFIG='+JSON.stringify(runtime)+';\n'+api.replace(/^export /gm,'')+'\n'+engine.replace(/^export /gm,'')+'\n'+app+'\n})();';
const json=JSON.stringify(JSON.parse(data)).replace(/</g,'\\u003c');
const html=template.replace('/*__CSS__*/',()=>css).replace('/*__DATA__*/',()=>json).replace('/*__SCRIPT__*/',()=>script.replace(/<\/script/gi,'<\\/script'));
await mkdir(new URL('dist',import.meta.url),{recursive:true});
await mkdir(new URL('dist/assets',import.meta.url),{recursive:true});
await copyFile(new URL('src/assets/favicon.svg',import.meta.url),new URL('dist/assets/favicon.svg',import.meta.url));
for(const name of ['decision-chain.webp','decision-chain.webp.json','manpan-sans.ttf','manpan-sans-OFL.txt']){
  await copyFile(new URL('src/assets/'+name,import.meta.url),new URL('dist/assets/'+name,import.meta.url));
}
await mkdir(new URL('dist/assets/spotkit',import.meta.url),{recursive:true});
for(const name of [...Object.values(illustrationFiles),'LICENSE-spotkit.txt','LICENSE-phosphor.txt','SOURCE.json']){
  await copyFile(new URL('src/assets/spotkit/'+name,import.meta.url),new URL('dist/assets/spotkit/'+name,import.meta.url));
}
await mkdir(new URL('dist/assets/hero-link',import.meta.url),{recursive:true});
for(const name of ['split-link.png','split-link.webp','split-link.source.json','split-link.webp.json','split-link.prompt.txt']){
  await copyFile(new URL('src/assets/hero-link/'+name,import.meta.url),new URL('dist/assets/hero-link/'+name,import.meta.url));
}
await mkdir(new URL('dist/assets/hero-mark',import.meta.url),{recursive:true});
for(const name of ['confluence.png','confluence.webp','confluence.source.json','confluence.prompt.txt']){
  await copyFile(new URL('src/assets/hero-mark/'+name,import.meta.url),new URL('dist/assets/hero-mark/'+name,import.meta.url));
}
await writeFile(new URL('dist/index.html',import.meta.url),html);
await mkdir(new URL('dist/docs',import.meta.url),{recursive:true});
for(const name of ['API-INTEGRATION.md','integration-openapi.json']){
  await copyFile(new URL('docs/'+name,import.meta.url),new URL('dist/docs/'+name,import.meta.url));
}
console.log('Built dist/index.html · '+(Buffer.byteLength(html)/1024).toFixed(1)+' KB + self-hosted assets');
