---
name: "满盘有数"
description: "渠道经营决策演示：连接数据、证据与下一步。"
colors:
  "paper": "#fff"
  "ink": "#17151d"
  "muted": "#74717b"
  "text-secondary": "#706878"
  "text-meta": "#75677f"
  "subtle": "#f8f7fa"
  "line": "#e8e6ec"
  "violet": "#7645c6"
  "violet-ink": "#6635b3"
  "violet-soft": "#f3eefb"
  "orange": "#e99543"
  "orange-ink": "#97521c"
  "gold": "#e2c667"
  "gold-ink": "#7d6314"
  "button-secondary-bg": "#f3f1f7"
  "button-secondary-ink": "#312a3c"
typography:
  display:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "56px"
    fontWeight: 750
    lineHeight: 1.42
    letterSpacing: "-0.035em"
  headline:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "36px"
    fontWeight: 700
    lineHeight: 1.45
    letterSpacing: "-0.03em"
  page-title:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "32px"
    fontWeight: 700
    lineHeight: 1.45
    letterSpacing: "-0.03em"
  panel-title:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "29px"
    fontWeight: 650
    lineHeight: 1.5
    letterSpacing: "-0.025em"
  body:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "15px"
    fontWeight: 400
    lineHeight: 1.7
  label:
    fontFamily: "'Manpan Sans', -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif"
    fontSize: "13px"
    fontWeight: 600
    lineHeight: 1.5
rounded:
  "badge": "5px"
  "button": "7px"
  "field": "8px"
  "icon": "10px"
  "preview": "11px"
  "card": "14px"
  "modal": "16px"
  "feature": "18px"
spacing:
  "4": "4px"
  "8": "8px"
  "12": "12px"
  "16": "16px"
  "20": "20px"
  "24": "24px"
  "28": "28px"
  "32": "32px"
  "40": "40px"
  "48": "48px"
  "76": "76px"
components:
  button-primary:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.paper}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "11px 18px"
  button-secondary:
    backgroundColor: "{colors.button-secondary-bg}"
    textColor: "{colors.button-secondary-ink}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "11px 18px"
  button-soft:
    backgroundColor: "{colors.violet-soft}"
    textColor: "{colors.violet-ink}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "11px 18px"
  button-quiet:
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "11px 4px"
  field:
    backgroundColor: "{colors.paper}"
    rounded: "{rounded.field}"
    padding: "11px 13px"
  navigation:
    backgroundColor: "{colors.paper}"
    height: "82px"
  badge:
    rounded: "{rounded.badge}"
    padding: "4px 8px"
  card:
    backgroundColor: "{colors.paper}"
    rounded: "{rounded.card}"
  capability:
    backgroundColor: "{colors.paper}"
    rounded: "{rounded.card}"
    padding: "20px"
  feature-tabs:
    textColor: "{colors.ink}"
---

# Design System: 满盘有数

## Overview

**Creative North Star: "连接数据、证据与下一步"**

以用户指定的 Innix 截图框架为视觉依据：白色顶部导航，左侧黑灰大标题，右侧原始紫、橙、金三环链条，随后是八项能力卡片和三组标签下的左右详情面板。整体留白清楚、信息专业，装饰集中在独立主视觉与能力预览。

经营工作区沿用相同字体、白底、细边框和圆角，缩短段落与控件之间的距离，让数据、证据、人工决定和后续动作容易顺着读。本文从现有源代码提取可复用规则；它记录当前实现，不代表最终视觉验收。环境没有 cua_repl.js，未使用替代浏览器，也没有真实浏览器截图；已有验证范围为 DOM 交互测试、静态 CSS 与资产检查。

**Key Characteristics:**
- 白色导航与白色工作画布，黑灰文字承担主要阅读。
- 工作能力仍按紫、橙、金分组；主视觉采用淡紫玻璃与香槟金的渐收薄带，表达数据走向判断。
- 展示区域疏朗，业务区域紧凑；两者共用字体、边框与控件。
- 能力选择、标签状态和业务入口相互接续，保留演示边界。

## Colors

白底与石墨色文字构成阅读底层，三种温度不同的装饰色标识工作分组。上方 frontmatter 是规范值；下述名称解释使用位置。

### Primary
- **链接紫 / violet**：品牌字、线性图标、数据分组、选中与交互提示。
- **紫色文字 / violet-ink**：浅紫按钮、浅紫标签中的文字；不要直接以装饰紫替代该角色。
- **柔紫底 / violet-soft**：轻量操作和选中提示的浅底。

### Secondary
- **证据橙 / orange**：证据分组的小标记。
- **证据橙文字 / orange-ink**：橙色图标底块内的图标前景。

### Tertiary
- **行动金 / gold**：判断图标与处置回访分组标记。
- **行动金文字 / gold-ink**：淡金底块内的图标前景。

### Neutral
- **白纸 / paper**：页面、顶部导航、卡片与表单底色。
- **墨色 / ink**：大标题、主要操作按钮与高优先级文字。
- **阅读灰 / muted**：基础页面描述与常规辅助文字。
- **工作次级文字 / text-secondary**：工作区说明、表格正文、对话、抽屉与弹窗说明、表单标签及辅助字段，映射到 `--text-secondary`。
- **元信息文字 / text-meta**：插画摘要与图注、图表选择控件、案件附注与页尾声明，映射到 `--text-meta`。
- **淡灰底 / subtle**：次级工作区域。
- **细分隔 / line**：常规边界、分隔线与指标分组。
- **次按钮底 / button-secondary-bg** 与 **次按钮文字 / button-secondary-ink**：主要动作旁的次级按钮。

**The Foreground Rule.** 正文、标题与辅助说明使用各自的语义前景角色；工作区次级文字使用 text-secondary，元信息使用 text-meta，不要直接从紫、橙、金的装饰色推导文字色。各分组预览的特殊图注前景仍以当前 src/style.css 的最终覆盖规则为准。

**The Linked Groups Rule.** 能力分组继续使用紫色的数据洞察、橙色的证据核验、金色的处置回访；选中状态同时以边框、下划线或字重表达。


## Typography

**Display Font:** 本地 `Manpan Sans` 字体别名；源方向将该拉丁字体标为 Plus Jakarta Sans。实际加载文件为 `src/assets/manpan-sans.ttf`，可变字重（200–800），`font-display: swap`。

**Body Font:** 与展示字体共用同一字体栈；中文按系统的 PingFang SC、Noto Sans CJK SC、Microsoft YaHei 等字体回退。

**Label/Mono Font:** 没有独立等宽字库。数字与金额继续用同一字体并开启 `font-variant-numeric: tabular-nums`。

**Character:** 拉丁文字和数字紧凑、圆润，中文采用熟悉的无衬线字形。标题靠字号、字重和黑灰分行建立层级，辅助标签保持轻量。

### Hierarchy
- **Display**：首页两行主标题采用 frontmatter 的 display；第二行为灰色。基础字号（56px）随宽度变化为大屏（62px）、1250px 以下（48px）、1000px 以下（41px）、860px 以下（37px）、600px 以下（36px）、370px 以下（32px）。手机行高为（1.5）。
- **Headline**：首页分区标题使用 headline；大屏（39px），1000px 以下（31px），860px 以下（29px），600px 以下（27px），370px 以下（24px）。
- **Page title**：操作页主标题使用 page-title；1000px 以下（29px），600px 以下（27px）。Agent 页首另用（24px / 650），手机（22px）。
- **Panel title**：详情文案标题使用 panel-title；预览、工作卡片和对话有更紧凑的次层级。Agent 欢迎标题为（40px / 650 / 1.5），手机（30px）。
- **Body**：全局正文使用 body；展示区说明行高（1.9），详情区说明行高（2），工作区按上下文使用（12–14px）。详情文案在桌面限制为（52ch）。
- **Label**：按钮使用 label；常规导航（13px），辅助说明（11–12px）。详情摘要使用（11–16px）HTML 文字，数字为（22–24px）；插画内部没有文字。

## Layout

顶部导航固定在滚动容器上沿（sticky），基础高度（82px），容器最大宽度（1600px），水平内边距（40px）。主内容最大宽度（1280px）；首页（1360px），Agent 内容（1080px），Agent 对话列（900px）。标准内容顶部留白（48px），首页由主视觉区自行控制。

桌面首屏两列比例（1.04fr / 1fr），列间距（22px），基础最小高度（498px），内边距上（72px）下（52px）。右侧互动图示按原始图片比例显示，最大宽度（640px）；布局窗口收紧上下各 75 原图像素的白色留白。原始白底 RGB 图片不作裁切，完整图由下载路径提供。主视觉不再覆盖网格。

首页能力矩阵为四列、两行，共八项，间距（16px），卡片最小高度（164px）。详情为三标签，基础标签间距（32px）；详情面板两列等宽、内边距（14px）、最小高度（465px）。左侧为文字、检查项、边界与入口；右侧为 Spotkit 几何插画与可读 HTML 数据摘要，不再使用微缩业务窗口。

工作区基础指标为四列；趋势与关注列表采用（剩余宽度 / 320px）双列。常用间距见 frontmatter：小控件使用（4–12px），卡片与工作组使用（16–32px），内容与展示分区使用（40–76px）。这些是实际重复值，不是要求所有距离严格落在单一倍数上。

### Responsive behavior
- **1650px 及以上**：首页容器（1450px），横向内边距（50px），首屏最小高度（560px）；互动图示最大宽度（640px）。
- **1250px 及以下**：压缩导航间距与首页文案、能力卡片、数据区的内部尺寸。
- **1000px 及以下**：内容横向内边距（28px）；趋势和关注区纵排，关注项仍可横向三列；详情仍为左右双列。
- **860px 及以下**：导航高度（70px），主导航由菜单按钮展开成双列，浮在页面上方并有遮罩；详情面板和普通双列工作区改为单列，能力矩阵改为两列；卡片描述不低于（12px）。
- **601–760px**：首屏改为上下布局，标题（44px）、互动图示按比例排列，避免双列挤压中文标题。
- **600px 及以下**：内容横向内边距（18px），首屏先文案后链条；互动图示使用自适应高度，最大宽度（440px）。能力矩阵、指标和案件统计为两列，Agent 建议为单列，表单同行字段纵排；案件表保留横向滚动（最小宽度 790px）。页尾纵排。
- **370px 及以下**：横向内边距（14px），进一步调整标题和插画摘要内边距，不删除业务入口。

**The Two Density Rule.** 首页展示区保留大标题与段落留白；案件、规则、表格和对话使用较紧的工作密度，不把整页重新包进密集浅紫卡片。

## Elevation & Depth

页面采用平面白色表面与细线分隔，深度集中在链条材质、Spotkit 浮动图形和临时浮层。普通工作卡片没有投影。柔和阴影不承担业务状态的唯一标识。

### Shadow Vocabulary
- **Spotkit 插画浮层**：沿用原规范的唯一 `feDropShadow`，正文与事实摘要保持平面；见资产来源与规范。
- **案件抽屉**（`-15px 0 65px #32144216`）：右侧抽屉与遮罩下的页面分层。
- **弹窗**（`0 20px 75px #3716441c`）：居中任务弹窗的环境阴影。
- **移动导航**（`0 12px 20px #31203d0d`）：860px 以下的展开菜单。
- **提示条**（`0 7px 25px #3d194521`）：页面底部短暂反馈。
- **分段选项**（`0 1px 4px #2815320b`）：图表分段控件的白色选中项。

**The Flat Surface Rule.** 普通卡片以白底和细边框分组；柔和阴影用于预览叠层、浮层与短暂反馈。

### Hero asset provenance

当前使用用户要求恢复的 `src/assets/decision-chain.webp`，原始透明 PNG 与生成来源仍在同目录。静态三环不承担按钮语义，不再分割图像或播放连接动效。布局使用原始比例，桌面最大宽度580–620px，手机362px，并为图片声明1495×1052尺寸。

网站顶部与页尾提供分享入口；分享弹窗复制经过清理的当前页面链接，保留有效能力定位、移除未知查询参数，不包含访客的本地问答或证据。数据页用两个并列的接入状态区分业务系统与分析 Agent；尚未配置时不发起外部请求。真实接口批次先作为独立预览，不能混入旧演示案件。

新增卡片沿用现有字体、细边框与24px内边距，手机改为单列。分享控件在小屏保留44px触控区域，减少重复的顶部演示标签，为导航留出空间。

## Shapes

控件采用小圆角，容器采用更宽的柔圆角，具体值由 frontmatter 对应角色定义。按钮与分段容器较紧；输入框略宽；卡片、弹窗、详情框逐级柔和。主要边框为（1px）。品牌符号保留胶囊状链环，主视觉恢复三环链条；标签、工作表单和工作卡片仍保留直线边界，避免将所有元素都变成胶囊。

图标为内联 SVG 线性图标，24 网格、统一笔画（1.75）；常规显示（19px）、小图标（16px）、大图标（25px）。八枚能力图标按 Premium Vector Icon Designer 方法重新制作，源片段在 `src/assets/feature-icons.json`，可编辑图集在 `feature-icons.svg`。能力图标底块桌面（42 × 42px）、手机（38 × 38px），内部图标（21px）。助手改为圆角机器人轮廓；图像与图标均不使用 Emoji。

## Components

### Buttons

紧凑、清楚，优先级由实底与浅底区分。

- **Primary**：墨色实底与白色文字，使用 button-primary；常规最小高度（44px），首页主操作（46px）。
- **Secondary**：浅灰紫底与深色文字，带细边框；hover 进一步加深底色。
- **Soft**：柔紫底与紫色文字，用于轻量动作。
- **Quiet**：透明底，减少水平内边距；hover 转为品牌紫。
- **Hover / Focus**：常规背景、文字、边框过渡（0.18s）。全局键盘焦点为（3px）可见轮廓和（4px）外偏移；禁用按钮降低透明度（0.45）并停用指针动作。

### Chips

徽标采用小圆角与浅底，文字（11px），可含继承文字色的圆点。浅紫变体承载核验 / 决策状态，描边变体用于本地记录、版本、待核验等信息。状态保留文字说明，不能只看颜色。

### Cards / Containers

普通卡片为白底、细边框和 card 圆角。标题区常见内边距为上（23px）、左右（24px）；内容区按图表、列表、表格或说明文体调整。指标组共享一个外框，通过内分隔区分指标。桌面能力卡片内边距（20px），hover 改变边框和底色；选中状态加强紫色边框，并以 `aria-pressed` 暴露。

### Inputs / Fields

白底、细边框、field 圆角，内边距（11px 13px），最小高度（44px）。焦点改变边框并绘制（2px）浅色轮廓、偏移（1px）。文本域支持纵向调整大小，常规最小高度（110px）。字段标签和说明在输入框外部排列，错误在表单内以独立文字区显示。对话输入为独立 composer 外框，焦点在容器内时加强边框。

### Navigation

白色 sticky 顶部导航始终提供经营概览、Agent 助理、案件工作台、历史回放、数据与批次、规则与口径六个入口。桌面当前页用较深文字、字重与底部细紫线标识，`aria-current="page"` 对应 URL hash。窄屏展开菜单使用双列链接、遮罩、展开状态与焦点管理；Esc 关闭并返回菜单按钮。

### Capability detail

八项能力按紫 / 橙 / 金分为数据、证据、行动三组。点击卡片更新 `capability` 查询参数、同步详情分组并滚动到详情；重新打开 URL 恢复所选能力。三个标签以黑色下划线和字重标识选中项，采用 `tablist` / `tab` / `tabpanel` 与 roving tabindex。左右方向键切换，Home / End 到首尾；切换后焦点留在活动标签。

详情左侧保留标题、说明、四条能力检查项、使用边界和业务入口；右侧按分组切换 Spotkit L9 数据汇入、L12 证据状态和 L11 回访时间线。三者沿用 160 方形画布、0.5 结构线、Phosphor regular 填充图形，独立 ID 避免遮罩冲突。SVG 内无文字，事实与演示边界由下方 HTML 摘要承载。来源、原始 commit、校验值和 MIT 许可保存在 `src/assets/spotkit/`。数据摘要显示真实脱敏汇总数；其余为明确标注的流程示例。

### Working interactions and overlays

图表支持指标、7 / 14 / 30 日窗口、数据点与明细表；案件支持搜索、状态和负责人筛选、补证、审查登记、人工决定、执行凭证与回访；Agent 保留本地预设回答和来源；历史回放逐日播放。新增演示记录保存至当前浏览器的 localStorage。不会调用在线模型或修改真实投放系统。

案件抽屉从右侧打开，宽度上限（680px），高度铺满；弹窗常规宽度上限（520px），宽版（760px），并限制在视口内滚动。二者具有 dialog 语义、标签、遮罩、Esc 关闭、Tab 焦点约束与返回焦点。全局快捷键 Ctrl / ⌘ K 搜索，非编辑时 `?` 打开帮助。常规弹窗出现（0.16s），抽屉出现（0.2s），easing 使用 `--ease`。分组选择保留原有按钮与焦点，底部指示线以 transform 在（200ms）内跟随；详情以 opacity 与（6px）短位移入场，页面导航使用（160ms）淡入。使用原生 Web Animations API，快速切换会取消旧动画；不引入 GSAP、滚动劫持或循环装饰。减少动态效果时仅保留（100ms）淡入和颜色反馈，关闭位移、抽屉滑动和输入等待脉冲，滚动使用即时行为；监听系统偏好的实时变化。

## Do's and Don'ts

### Do:
- **Do** 保持白色顶部导航、左文右互动图示、八能力卡片与三标签详情框架。
- **Do** 使用本地字体、SVG 线性图标和真实文字构成界面；保留链条资产的透明开孔。
- **Do** 为选择状态保留可读文字、结构性标识和语义属性；让能力入口实际到达业务操作。
- **Do** 在窄屏将展示区纵向排列，同时保留表格横向滚动、键盘焦点和减少动态效果。
- **Do** 同时展示数据来源与演示限制，区分接受建议、实际执行、观察结果与已验证收益。

### Don't:
- **Don't** 用 Emoji 替代已实现的线性 SVG 图标。
- **Don't** 把整页 UI 栅格化为图片，也不要为链条图片增加不透明底板。
- **Don't** 将装饰色直接用作全部正文，或把小字号预览辅助字推广为正文规范。
- **Don't** 隐藏焦点、来源、使用边界或真实脱敏数据与流程示例之间的区别。
- **Don't** 将 DOM 测试通过表述为真实浏览器截图、移动端或视觉验收通过。


## 本轮精修与检查

主页能力图标增加交互式轻抬、按压回弹与单次柔光扫过；历史图标轻转、Agent 图标眨眼。键盘聚焦获得同等反馈，触屏使用按压反馈。链条主视觉已由新的点击连接互动替代悬停浮起。全部新效果仅在 `prefers-reduced-motion: no-preference` 下启用，没有自动循环，不改变卡片尺寸或业务状态。

延续参考图方向，仅更新图标、能力详情插画、选中语义、平板布局与操作反馈。新增图解表面的数据 / 证据 / 行动颜色分别为 `#f8f7fb` / `#fcf9f5` / `#fbfaf4`，证据与行动说明文字为 `#76624b` / `#72643c`；正文仍使用原有石墨色角色。辅助分隔线和能力图标底色均为这三组的轻量派生。

设计检测返回 308 条 advisory：201 条字面颜色、92 条字号、14 条圆角未在原简化 frontmatter 中穷举，以及 1 条参考图主视觉网格。没有非 advisory 项。它不等同于完整可访问性或视觉批准；未将这些既有及派生值批量加入忽略清单，也未声称检测完全清零。网格保留为用户指定的主视觉框架。真实浏览器、滚动和动效帧率验证仍受工具缺失限制。


## 当前交付检查
23项自动测试通过，包含原图恢复、分享、接口禁用状态、批次校验和超时。浏览器控制工具仍不可用；DOM/CSS检查不等于整页视觉或触控验收。此前主视觉实验记录不作为当前实现规范。
