# PPT 与幻灯片设计 Skills

2026-11-14 整理。5 个主技能入口：新增4项，复用并校验已有 Theme Factory。
已安装到当前执行环境的 `/home/agent/.agents/skills/`，兼容入口在 `/home/agent/.codex/skills/`。
这是当前环境的文件安装，不等于账号级永久注册；客户端是否自动发现、是否需要重载取决于其实现。

## 选择什么来做PPT

| 技能 | 适合做什么 | 主要产物 |
|---|---|---|
| pptx | Anthropic官方：创建/编辑PowerPoint、模板、原生图表、讲者备注及结构和视觉校验 | 原生可编辑 .pptx；编辑能力按实际对象和素材类型判断 |
| baoyu-slide-deck | 宝玉：内容大纲、逐页提示词、16组原始预览和多种视觉风格 | 逐页图片，再合并PPTX/PDF；图片中的文字不是原生可编辑文本 |
| frontend-slides | 动态网页演示、视觉风格预览、PPTX导入转网页、演讲者备注 | HTML；PDF为静态输出 |
| slide-design-skill | SlideSpeak：按内容生成设计系统，内置pitch/consulting/training等8组风格资料、图表和表格 | HTML设计引擎及PDF相关工具；不是直接原生PPTX导出器 |
| theme-factory | 10组字体与配色搭配，含主题预览PDF；此前已安装，本次保留原安装 | 主题参考，不单独导出幻灯片文件 |

## 热榜核对

实际查看了2026-11-14的GitHub日榜、周榜和月榜。`anthropics/skills` 出现在本次周榜和月榜。
宝玉、Frontend Slides及SlideSpeak是专项补充来源，未宣称它们也位列本次热榜。
快照、固定提交、源路径、Git blob校验值和SHA256均附在包内；上游许可证保留。

## 怎么用

需要可编辑PPT文件，以 `pptx` 为主，再参考 Theme Factory 统一字体与配色。
需要逐页图像风格，选择宝玉技能；需要网页动效，选择 Frontend Slides；商务路演和咨询叙事可参考 SlideSpeak 的 pitch/consulting 资料。
不同技能有各自的视觉默认值；按具体任务选主流程，不机械叠加冲突的样式要求。用户明确的品牌、参考图、尺寸和授权范围优先。

在其他工具中使用，可将所需 `skills/<名称>/` 整个目录复制到该工具认可的技能目录，保留现有同名版本后再处理。
原生PPTX、图片PPTX、HTML、PDF是不同交付形式；图像合并PPTX不等于所有文字图形都可逐项编辑。

## 运行环境

本轮仅下载、审阅、文件安装和打包，未执行上游安装器、工作流、依赖安装、发布脚本或收费模型调用，也未新增API密钥或偏好配置。
PPTX通常使用Node/PptxGenJS及Python工具；PDF预览依赖实际环境中的LibreOffice等工具。上游写的“预装”不代表每个用户环境都已满足。
宝玉合并脚本需要Bun/相应运行器与pptxgenjs或pdf-lib；图片生成使用当前任务可用并已授权的图像工具。
SlideSpeak的引擎依赖需在实际使用时检查；AI图像功能为可选，未配置或调用FAL等供应商服务。
下载不代表已为任何外部服务登录或开通额度。真正制作时再按选定技能检查必要依赖。

## 资源位置

- `skills/pptx/SKILL.md`：原生PPTX主入口。
- `skills/baoyu-slide-deck/assets/style-previews/`：16张上游风格预览，原始文件和来源校验均保留。
- `skills/slide-design-skill/skills/pitch/`：路演叙事和设计资料；`skills/consulting/`：咨询报告风格资料。它们是引擎内部风格资源，不是本次额外安装的独立入口。
- `skills/theme-factory/theme-showcase.pdf`：字体与配色预览。

## 路演制作提醒

先确认受众、时间和讲稿，再确定每页的单一结论及视觉证据。数据注明来源，事实、估算和计划分别表达；专业术语对应具体实现，避免把试点目标写成已验证成果。
中文排版要检查字体覆盖、字号、断行、图表标签及投影可读性。可编辑PPT交付应包含讲者备注并做结构、文字与渲染检查。
